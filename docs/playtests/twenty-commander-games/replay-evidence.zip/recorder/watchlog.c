/* Read-only recorder for timestamped first-person replay events. */
#include "watchlog.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static FILE *out;
static int current_line, inside_dispatch;

static void quoted(const char *s) {
    fputc('"', out);
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p == '"' || *p == '\\') { fputc('\\',out); fputc(*p,out); }
        else if (*p < 32) fprintf(out,"\\u%04x",*p);
        else fputc(*p,out);
    }
    fputc('"',out);
}
static void field(const char *k, const char *v) {
    fprintf(out,",\"%s\":",k); quoted(v);
}
static void num(const char *k, int v) { fprintf(out,",\"%s\":%d",k,v); }
static void flag(const char *k, bool v) { fprintf(out,",\"%s\":%s",k,v?"true":"false"); }
static void open_event(const char *event, const Sim *g) {
    fputs("{\"event\":",out); quoted(event); num("line",current_line); num("tick",g->tick);
}
static void close_event(void) { fputs("}\n",out); }
static void state(const Sim *g) {
    field("result",g->result); field("stage",g->stage); field("objective",g->objective);
    num("alloy",g->blue.alloy); num("reserved",g->reserved); num("progress",g->progress);
    num("hold_blue",g->blue.hold); num("hold_red",g->red.hold); num("clock",g->clock);
    field("report",g->report); num("report_at",g->report_at);
}
static void pose(const App *a) {
    static const char *panels[]={"field","orders","guide","operations","crew register","crew assignment","radio","chart"};
    V3 p = camera_eye(&a->camera,&a->sim);
    field("panel",panels[a->panel]);
    field("aboard",a->camera.aboard>=0?a->sim.place[a->camera.aboard].key:"");
    fprintf(out,",\"eye\":[%.3f,%.3f,%.3f],\"yaw\":%.4f,\"pitch\":%.4f",p.x,p.y,p.z,a->camera.yaw,a->camera.pitch);
}
static int table_int(lua_State *L, const char *key) {
    lua_getfield(L,-1,key); int v=(int)lua_tointeger(L,-1); lua_pop(L,1); return v;
}
static void ledger(Sim *g) {
    lua_State *L=g->L;
    int top=lua_gettop(L);
    lua_rawgeti(L,LUA_REGISTRYINDEX,g->state);
    lua_getfield(L,-1,"done");
    int count=0;
    fputs(",\"done\":[",out);
    if(lua_istable(L,-1)) {
        lua_pushnil(L);
        while(lua_next(L,-2)) {
            if(lua_type(L,-2)==LUA_TSTRING && lua_toboolean(L,-1)) {
                if(count++) fputc(',',out);
                quoted(lua_tostring(L,-2));
            }
            lua_pop(L,1);
        }
    }
    fputc(']',out); lua_pop(L,1);
    lua_getfield(L,-1,"jobs"); count=0;
    fputs(",\"jobs\":{",out);
    if(lua_istable(L,-1)) {
        lua_pushnil(L);
        while(lua_next(L,-2)) {
            if(lua_type(L,-2)==LUA_TSTRING && lua_istable(L,-1)) {
                if(count++) fputc(',',out);
                quoted(lua_tostring(L,-2));
                int elapsed=table_int(L,"elapsed"), length=table_int(L,"length");
                fprintf(out,":{\"elapsed\":%d,\"length\":%d}",elapsed,length);
            }
            lua_pop(L,1);
        }
    }
    fputc('}',out); lua_settop(L,top);
}
void watch_start(App *a) {
    const char *path=getenv("ORRA_ACTION_LOG");
    if(!path || !(out=fopen(path,"w"))) { perror("open action log"); exit(3); }
    open_event("start",&a->sim); field("mission",a->sim.mission); field("title",a->sim.title);
    num("hold_target",a->sim.hold_ticks); state(&a->sim); pose(a); close_event();
}
void watch_before(App *a,int line,const char *kind,const char *arg,const char *extra) {
    current_line=line;
    open_event("before",&a->sim); field("directive",kind); field("arg",arg); field("extra",extra);
    state(&a->sim); pose(a); close_event();
}
void watch_after(App *a,bool ok) {
    open_event("after",&a->sim); flag("ok",ok); state(&a->sim); pose(a); close_event();
}
void watch_end(App *a,bool ok) {
    open_event("end",&a->sim); flag("ok",ok); state(&a->sim); pose(a); ledger(&a->sim);
    fprintf(out,",\"digest\":%u",sim_digest(&a->sim)); close_event();
    if(fclose(out)!=0) { perror("close action log"); exit(3); } out=NULL;
}
bool __real_sim_command(Sim *,int);
bool __real_sim_order(Sim *,const char *);
bool __real_sim_step(Sim *,int);
typedef struct { char report[160]; int at,alloy; } Receipt;
static Receipt prior(const Sim *g) {
    Receipt r={.at=g->report_at,.alloy=g->blue.alloy};
    snprintf(r.report,sizeof r.report,"%s",g->report); return r;
}
static void order_event(const Sim *g,const Order *o,Receipt r,bool ok,const char *via) {
    open_event("order",g); field("id",o->id); field("label",o->label); field("actor",o->actor);
    field("via",via); flag("accepted",ok); num("alloy_before",r.alloy); num("alloy_after",g->blue.alloy);
    field("report",g->report); num("report_at",g->report_at);
    flag("report_changed",r.at!=g->report_at || strcmp(r.report,g->report)); close_event();
}
bool __wrap_sim_command(Sim *g,int index) {
    if(!out) return __real_sim_command(g,index);
    Order o={0}; if(index>=0 && index<g->order_count) o=g->orders[index];
    Receipt r=prior(g); inside_dispatch++;
    bool ok=__real_sim_command(g,index); inside_dispatch--;
    order_event(g,&o,r,ok,"mission orders"); return ok;
}
bool __wrap_sim_order(Sim *g,const char *id) {
    if(!out || inside_dispatch) return __real_sim_order(g,id);
    Order o={0}; snprintf(o.id,sizeof o.id,"%s",id);
    for(int i=0;i<g->order_count;i++) if(!strcmp(g->orders[i].id,id)) {o=g->orders[i];break;}
    Receipt r=prior(g);
    bool ok=__real_sim_order(g,id);
    order_event(g,&o,r,ok,"crew dispatch"); return ok;
}
bool __wrap_sim_step(Sim *g,int ticks) {
    if(!out || strcmp(g->result,"active")) return __real_sim_step(g,ticks);
    char stage[sizeof g->stage]; snprintf(stage,sizeof stage,"%s",g->stage);
    Receipt r=prior(g); int progress=g->progress;
    bool ok=__real_sim_step(g,ticks);
    bool terminal=strcmp(g->result,"active")!=0;
    if(terminal || !ok || r.at!=g->report_at || strcmp(r.report,g->report) || strcmp(stage,g->stage) ||
       progress!=g->progress || r.alloy!=g->blue.alloy) {
        open_event(terminal?"terminal":"change",g); flag("ok",ok); state(g);
        if(terminal) ledger(g);
        close_event();
    }
    return ok;
}
