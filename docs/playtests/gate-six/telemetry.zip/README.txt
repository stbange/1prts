runs.csv columns: seed, policy, simulation tick, event kind, event-specific values.
input: order ID, accepted, changed; second: rival section approach fraction, rival armor approach fraction, rival hold fraction, prior-second inputs, player hold ticks; end: outcome, best hold fraction.
Other events record resources, warnings, arrivals and clock resets. timing/buffer rows record order, ticks early and actual execution.
ticks.csv records one proxy session each phase, including affordable offers on each order, alloy, stock, both sides' travel and hold ticks, and radio changes.
render.csv records process-relative milliseconds, input frame to changed radio pixels, completed-frame GPU times, per-tick movement and feedback observations. The PNG pairs recover the background underneath the rival section at the same instant.
