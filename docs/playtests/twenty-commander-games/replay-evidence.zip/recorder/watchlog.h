#include "app.h"
void watch_start(App *a);
void watch_before(App *a, int line, const char *kind, const char *arg, const char *extra);
void watch_after(App *a, bool ok);
void watch_end(App *a, bool ok);
