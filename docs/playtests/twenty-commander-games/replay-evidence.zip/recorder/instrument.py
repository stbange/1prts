from pathlib import Path
import sys

original = Path(sys.argv[1]).read_text()
edits = [
    ('#include "app.h"', '#include "app.h"\n#include "watchlog.h"'),
    ('    char line[384];', '    watch_start(a);\n    char line[384];'),
    ('        if (!strcmp(cmd, "key") ||', '        watch_before(a,n,cmd,arg,extra);\n        if (!strcmp(cmd, "key") ||'),
    ('            ok = false;\n    }\n    fclose(file);', '            ok = false;\n        watch_after(a,ok);\n    }\n    fclose(file);'),
    ('    return ok;\n}', '    watch_end(a,ok);\n    return ok;\n}'),
]
for old, new in edits:
    assert original.count(old) == 1, old
    original = original.replace(old, new)
Path("replay-observed.c").write_text(original)
