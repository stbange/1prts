# Twenty commander games

These are the inputs and observations from 20 independent Linux missions on 2026-11-22. The release build was `0.2-4037ef2986ba` from `stbange/1prts`. The commander used the first-person keyboard and mouse controls. All missions began at simulation tick zero with the stock content and a fresh save directory.

## Replay a game

Build or unpack the matching revision. Set `GAME_DIR` to the absolute path of its `bin` directory. From the directory containing this file, the following command replays game 06 with the stock executable.

```sh
SDL_VIDEODRIVER=offscreen SDL_AUDIODRIVER=dummy LIBGL_ALWAYS_SOFTWARE=1 \
  ORRA_COMPACT_REPLAY=1 "$GAME_DIR/1stprts" --data "$GAME_DIR" \
  --mission tide-window --replay routes/06.route
```

Use `plan.json` for the mission ID of any other route. `checkpoint finish` prints the terminal tick, result and a world checksum. To save the rendered shots, set `ORRA_CAPTURE_DIR` to an existing directory. Exact image hashes can vary with graphics drivers. The included files are lossless 288 × 162 RGB PPM images from the run.

## Read a timeline

Each line of `events/NN.jsonl` is a JSON object in execution order. `line` is the line number in `routes/NN.route`. Simulation time in seconds is `tick / 30`.

- `start` captures the initial mission state. `before` and `after` surround every replay directive. Both include the active panel, camera eye, heading and vessel. An empty vessel ID indicates the commander is on foot. An empty stage is valid for missions without named stages.
- `order` records the order ID and the Boolean returned by the simulation. `report` is the radio text at that instant. `report_changed` indicates whether the text or its timestamp changed during dispatch. Two orders can produce identical text at the same tick.
- `change` records changes during a simulation step to the radio, stage, progress or alloy. `terminal` is the first tick with a victory or defeat. `done` and `jobs` expose completed and pending jobs on operations that keep those ledgers. Job lengths and elapsed times are in ticks.
- `end` and `checkpoints/NN.txt` contain the final checksums. Assertions, draws and excess wait ticks after the result are replay bookkeeping. The simulation clock stops at the terminal tick.

The recorder linked the release engine, Lua and simulation libraries. It surrounded the stock replay driver's directives with read-only observation calls and recorded returns from `sim_command`, `sim_order` and `sim_step` through GNU linker wrapping. The recorder source and the transformation for `src/replay.c` are in `recorder/`. The routes themselves work with the stock executable.

Code uses the repository's MIT license. Screenshot credit is “Orra Basin, 1stprts contributors, CC BY 4.0.” [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) · [Source, license and art credits](https://github.com/stbange/1prts/tree/4037ef2986ba5069c9d313b8efdea059bba8b966)
